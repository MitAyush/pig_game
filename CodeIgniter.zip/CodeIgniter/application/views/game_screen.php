<!DOCTYPE html>
<html>
<head>
	<title>Pig Game</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/app.css">
	<script src="https://kit.fontawesome.com/4e931c6c14.js"></script>
</head>
<body>
	<h2 style="margin-left: 44%;font-size: 30px;">Pig Game</h2> 
	<div class="main-board">
		<div class="subdivleft">
			<h1>Player 1</h1>
			<div class="player1-life"></div>
			<label class="player1_total_score" id="player1_total_score">0</label>
			<div class="current-box">
				<h3>Current</h3>
				<label id="player1-current">0</label>
			</div>
		</div>
		<div id="new-game" >
			<h2 onclick="new_game()"><i class="fas fa-plus-circle"></i> New Game </h2>
			<i style="margin-top:59%; margin-left: 18%;" id="main-dice" class="fas fa-dice-two fa-7x"></i>
		</div>
		<div id="roll-dice">
			<h2 onclick="roll_dice()"><i class="fas fa-sync"></i> Roll </h2>			
		</div>
		<div id="hold-dice" onclick="hold_dice()">
			<h2><i class="fas fa-hand-paper"></i> Hold </h2>		
		</div>
		<div class="subdivright">
			<h1>Player 2</h1>
			<div class="player2-life"></div>
			<label class="player2_total_score" id="player2_total_score">0</label>
			<div class="current-box">
				<h3>Current</h3>
				<label id="player2-current">0</label>				
			</div>
		</div>		
	</div>
</body>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
</script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/app.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</html>