var base_url = 'http://localhost/pig_game/codeigniter/'

$(document).ready(function() {
	var obj = document.createElement("audio");
	obj.src = base_url+"assets/audio/button_click.wav";
	obj.volume = .7;
	obj.autoPlay = false;
	obj.preLoad = true;
	obj.controls = true;
	obj.play();
	/*$(".playSound").click(function() {
	obj.play();
	// obj.pause();
	});*/
	var winner;
	if (Math.floor(Math.random()*100 + 1)%2 == 0)
		winner = 1;
	else
		winner = 2;

	if (winner == 1) {
		$(".player1-life").addClass("active-player");
		active_player = 'player1-current'
		swal("Player 1 will play first");
	}
	else{
		$(".player2-life").addClass("active-player");
		active_player = 'player2-current'
		swal("Player 2 will play first");	
	}
});
var obj = document.createElement("audio");
	//obj.src = "http://localhost/pig_game/codeigniter/assets/audio/switch.wav";
	obj.volume = .7;
	obj.autoPlay = false;
	obj.preLoad = true;
	obj.controls = true;
var player_current = 0, player1_total_score = 0, player2_total_score = 0, active_player;
//active_player = 'player2-current';

function new_game(){
	var winner;
	player_current = 0; player1_total_score = 0; player2_total_score = 0;
	if (Math.floor(Math.random()*100 + 1)%2 == 0){
		winner = 1;
		active_player = 'player1-current'
	}
	else{
		winner = 2;
		active_player = 'player2-current'
	}

	document.getElementById('player1_total_score').innerHTML = 0;
	document.getElementById('player2_total_score').innerHTML = 0;

	$(".player1-life").removeClass("active-player");
	$(".player2-life").removeClass("active-player");		
	if (winner == 1) {
		$(".player1-life").addClass("active-player");
		swal("Player 1 won the toss");
	}
	else{
		$(".player2-life").addClass("active-player");
		swal("Player 2 won the toss");
	}

	/**************************sound**************/

	obj.src = base_url+"assets/audio/switch.wav";
	obj.play();
	
}

function hold_dice() {

	obj.src = base_url+"assets/audio/pen_clicking.wav";
	obj.play();
	if (active_player == 'player2-current') {
		player2_total_score = player2_total_score + player_current;
		document.getElementById('player2_total_score').innerHTML = player2_total_score;
		document.getElementById('player2-current').innerHTML = 0;
		active_player = 'player1-current';
		$(".player2-life").removeClass("active-player");
		$(".player1-life").addClass("active-player");
	}
	else if(active_player == 'player1-current'){
		player1_total_score = player1_total_score + player_current;
		document.getElementById('player1_total_score').innerHTML = player1_total_score;
		document.getElementById('player1-current').innerHTML = 0;
		active_player = 'player2-current';
		$(".player1-life").removeClass("active-player");
		$(".player2-life").addClass("active-player");
	}

	if (player1_total_score >= 100) {
		swal("Great", "Player 1 won the Game", "success");
		player_current = 0; player1_total_score = 0; player2_total_score = 0;
		document.getElementById('player1_total_score').innerHTML = 0;
		document.getElementById('player2_total_score').innerHTML = 0;
		$(".player1-life").removeClass("active-player");
		$(".player2-life").removeClass("active-player");
		active_player = ''
		obj.src = base_url+"assets/audio/clap.mp3";
		obj.play();
	}
	else if(player2_total_score >= 100){
		swal("Sweet", "Player 2 won the Game", "success");
		player_current = 0; player1_total_score = 0; player2_total_score = 0;
		document.getElementById('player1_total_score').innerHTML = 0;
		document.getElementById('player2_total_score').innerHTML = 0;
		$(".player1-life").removeClass("active-player");
		$(".player2-life").removeClass("active-player");
		active_player = ''
		obj.src = base_url+"assets/audio/clap.mp3";
		obj.play();
	}
	player_current = 0;

}

function roll_dice() {
	
	var dice = Math.floor(Math.random()*6 + 1);
	var rand_num = dice;
	player_current = player_current + dice;
	switch(dice){
		case 1:
			dice = 'fas fa-dice-one fa-7x'
			break;
		case 2:
			dice = 'fas fa-dice-two fa-7x';
			break;
		case 3:
			dice = 'fas fa-dice-three fa-7x'
			break;
		case 4:
			dice = 'fas fa-dice-four fa-7x';
			break;
		case 5:
			dice = 'fas fa-dice-five fa-7x'
			break;
		case 6:
			dice = 'fas fa-dice-six fa-7x';
			break;
		default :
			dice = 'fas fa-dice-one fa-7x'
	}
	//document.getElementById('#main-dice').className ="";
	var classname = $('#main-dice').attr('class');
	$("#main-dice").removeClass(classname);
	$("#main-dice").addClass(dice);
	if (rand_num == 1) {
		document.getElementById(active_player).innerHTML = 0;
		player_current = 0;
		switch_player();
		
	}
	else	
		document.getElementById(active_player).innerHTML = player_current;

	obj.src = base_url+"assets/audio/computer_error.wav";
	obj.play();
}

function switch_player() {
	if (active_player == 'player1-current'){
		$(".player1-life").removeClass("active-player");
		$(".player2-life").addClass("active-player");
		active_player = 'player2-current';
	}
	else{
		$(".player2-life").removeClass("active-player");
		$(".player1-life").addClass("active-player");
		active_player = 'player1-current';
	}

}